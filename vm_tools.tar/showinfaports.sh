
searchdir=/opt/infa
ls $searchdir | while read d; do
	domains=$searchdir/$d/domains.infa
	#if [ -f $searchdir/$d/domains.infa ]; then
	if [ -f $domains ]; then
		port=`grep "<port>" $domains`
		echo $d $port
	fi
done
