#!/bin/bash

IFS=" " 
echo `sqlplus -s sys/infa@orcl as sysdba << EOF 
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
select username from dba_users; 
EOF` | while read user; do
  echo $user 
done

echo $a

exit 0
