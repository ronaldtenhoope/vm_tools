alter user mdm_usr identified by mdm_usr

