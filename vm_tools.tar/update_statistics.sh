#!/bin/bash
if [ $# -eq 1 ]; then
  envnumber=$1
  # Create users
  for schema in DMN PCR MMPCR MM MOD STG CACHE PROF HUMAN WF CMS; do
    schema_name=INFA_${schema}_${envnumber}
    echo $(sqlplus sys/infa@infaorcl as sysdba @/usr/local/bin/db/create_oracle_user.sql $schema_name) | while read tbl; do
      echo $tbl
    done
  done
fi
