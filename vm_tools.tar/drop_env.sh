#!/bin/bash
if [ $# -eq 1 ]; then
  envnumber=$1
  homedir=~
  # Create users
  for schema in DMN PCR MMPCR MM MOD MON STG CACHE PROF WF CMS DIH; do
    schema_name=INFA_${schema}_${envnumber}
    sqlplus sys/infa@orcl as sysdba @$homedir/.local/bin/db/drop_oracle_user.sql $schema_name
  done
fi

