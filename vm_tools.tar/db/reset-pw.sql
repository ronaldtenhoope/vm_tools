alter user INFA_DOMAIN identified by INFA_DOMAIN account unlock;
alter user INFA_MRS identified by INFA_MRS account unlock;
alter user INFA_MMWH identified by INFA_MMWH account unlock;
alter user INFA_MRS identified by INFA_MRS account unlock;
alter user INFA_PCREPO identified by INFA_PCREPO account unlock;
alter user INFA_PROFILING identified by INFA_PROFILING account unlock;
alter user INFA_STAGING identified by INFA_STAGING account unlock;
alter user INFA_CACHE identified by INFA_CACHE account unlock;
alter user INFA_HUMANTASK identified by INFA_HUMANTASK account unlock;
alter user INFA_STORAGE identified by INFA_STORAGE account unlock;
alter user PCREPO2 identified by PCREPO2 account unlock;

