if [ $# -eq 2 ]; then
  minport=$1
  maxport=$2
  sudo firewall-cmd --zone=public --add-port=$minport-$maxport/tcp --permanent
  sudo firewall-cmd --reload
fi

