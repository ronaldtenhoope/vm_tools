create user mmuser identified by mmuser default tablespace users temporary tablespace temp;
 
GRANT CONNECT TO mmuser;
GRANT SELECT_CATALOG_ROLE TO mmuser;
 
exit;
