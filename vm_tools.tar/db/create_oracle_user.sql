create user &1 identified by &1 default tablespace users temporary tablespace temp;
GRANT create session TO &1;
GRANT create table TO &1;
GRANT alter table TO &1;
GRANT create view TO &1;
GRANT create force view TO &1;
GRANT create cluster TO &1;
GRANT create any trigger TO &1;
GRANT create any procedure TO &1;
GRANT create sequence TO &1;
GRANT create synonym TO &1;

alter system set open_cursors=1000 scope=both sid='*';
alter system set cursor_sharing = force;
alter user &1 quota unlimited on users;
exit;

